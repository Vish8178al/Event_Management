package com.vishal.event.Modal;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;


public class DAO {
  private Connection c;
  public DAO() throws ClassNotFoundException,SQLException{
	  Class.forName("oracle.jdbc.driver.OracleDriver");
	  c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","Event_Management","Event_Management");
		 
  }  
  public void closeConnection() throws SQLException{
	  c.close();
  }
     public String adminLogin(String id,String password) throws SQLException{
    	 PreparedStatement p=c.prepareStatement("select * from admin where id=? and password=?");
    	 p.setString(1, id);
    	 p.setString(2, password);
    	 ResultSet rs=p.executeQuery();
    	 if(rs.next()) {
    		return rs.getString("name");
    	 }else {
    	 return null;
     }
     }
     
     public String userLogin(String email,String password) throws SQLException{
    	 PreparedStatement p=c.prepareStatement("select * from users where email=? and password=?");
    	 p.setString(1, email);
    	 p.setString(2, password);
    	 ResultSet rs=p.executeQuery();
    	 if(rs.next()) {
    		return rs.getString("name");
    	 }else {
    	 return null;
     }

     }
     
     public boolean registerUser(HashMap<String,Object> user) throws SQLException{
   	  			
				PreparedStatement p=c.prepareStatement("insert into users (name,email,password) values(?,?,?) ");
				 p.setString(1, (String)user.get("name"));
				 p.setString(2, (String)user.get("email"));
				 p.setString(3, (String)user.get("password"));
				 p.executeUpdate();
				return true;	 
	 
	  }
     
     public boolean addItem(String name,int phone) throws SQLException{
   	  try {
   		  PreparedStatement p=c.prepareStatement("insert into membership (name,phone) values(?,?) ");
   			 p.setString(1, name);
   			 p.setInt(2, phone);
   			 
   			 p.executeUpdate();
   			return true;
   	  }catch(SQLIntegrityConstraintViolationException e) {
   		  return false;
   	  }
   	
     }    
     
     }  
    
